<?php $__env->startSection('content'); ?>
    <register-component csrf_token="<?php echo e(@csrf_token()); ?>"></register-component>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Israelsilvaa\Documents\GitHub\TaskFlow\resources\views/auth/register.blade.php ENDPATH**/ ?>