<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Painel </div>

                    <div class="card-body">
                        Você está logado! <i class="fa-regular fa-face-laugh" style="color: #000000;"></i><i class="fa-solid fa-heart" style="color: #ff0000;"></i>
                    </div>

                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>
