@extends('layouts.app')

@section('content')
<tasks-component></tasks-component>
@endsection